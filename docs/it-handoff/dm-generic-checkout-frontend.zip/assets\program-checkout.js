/**
 * Program landing page → staging checkout handoff.
 * Builds a CRM-shaped cart from program JSON. Placeholder PartIDs must not be posted to production ProCheckout.
 */
(function (root) {
  const STORAGE_KEY = "dmProgramCart";
  const IDENTITY_KEY = "dmProgramIdentity";
  const SECRET_FIELDS = { password: true, ccNumber: true, ccCVV: true };

  function mapHardware(value) {
    const v = String(value || "").toLowerCase();
    if (v.includes("speaker") || v.includes("need new")) return "speakers";
    if (v.includes("playerone")) return "playerone";
    if (v.includes("sonos") || v.includes("ipad") || v.includes("tablet") || v.includes("app") || v.includes("pc") || v.includes("mac")) return "app";
    if (v.includes("unsure") || v.includes("not sure") || v.includes("existing")) return "app";
    return "app";
  }

  function needsLead(hardwareValue) {
    return mapHardware(hardwareValue) === "speakers";
  }

  const SETUP_NEXT_STEP = {
    sonos: { action: "checkout", playerKey: "app", hardwareValue: "Sonos", label: "Sonos" },
    bluetooth: { action: "checkout", playerKey: "app", hardwareValue: "iPad / phone app", label: "phone or tablet" },
    computer: { action: "checkout", playerKey: "app", hardwareValue: "PC / Mac", label: "store computer" },
    wired: { action: "lead", hardwareValue: "Wired speakers / amplifier" },
    unknown: { action: "lead", hardwareValue: "Not sure — help me choose" },
    new: { action: "lead", hardwareValue: "New location — audio system design" }
  };

  function setupNextStep(key) {
    return SETUP_NEXT_STEP[key] || { action: "lead", hardwareValue: "" };
  }

  function line(part, extras) {
    return Object.assign({
      skuCode: part.skuCode,
      crmPartId: part.crmPartId,
      name: part.name,
      price: part.price,
      recurring: !!part.recurring,
      shippable: !!part.shippable,
      quantity: 1
    }, extras || {});
  }

  function buildCart(program, selections) {
    if (!program || !program.music || !program.players) {
      throw new Error("Invalid program config");
    }
    const playerKey = selections.playerKey || mapHardware(selections.hardwarePreference);
    if (playerKey === "speakers") {
      throw new Error("Speaker quotes stay on the lead form");
    }
    const player = program.players[playerKey] || program.players.app;
    const items = [line(player), line(program.music, { shippable: false })];
    if (selections.messaging && program.addons && program.addons.messaging) {
      items.push(line(program.addons.messaging, { shippable: false }));
    }
    const subtotal = items.reduce((sum, item) => sum + Number(item.price || 0) * item.quantity, 0);
    return {
      programId: program.programId,
      programName: program.programName,
      salesmanEmail: program.salesmanEmail || "",
      placeholders: program.placeholders === true,
      placeholderNote: program.placeholderNote || "",
      crmCustomerId: program.crmCustomerId,
      playerKey,
      items,
      subtotal: Math.round(subtotal * 100) / 100,
      hasShipping: items.some((item) => item.shippable),
      contact: {
        locationName: selections.locationName || "",
        locationAddress: selections.locationAddress || "",
        contactName: selections.contactName || "",
        contactTitle: selections.contactTitle || "",
        contactEmail: selections.contactEmail || "",
        contactPhone: selections.contactPhone || "",
        notes: selections.notes || ""
      },
      hdcartLines: items.map((item) => ({
        label: "PartID",
        skuCode: item.skuCode,
        crmPartId: item.crmPartId,
        name: item.name,
        price: item.price
      }))
    };
  }

  function storage() {
    try {
      return typeof sessionStorage === "undefined" ? null : sessionStorage;
    } catch (err) {
      return null;
    }
  }

  function saveCart(cart) {
    const store = storage();
    if (store) store.setItem(STORAGE_KEY, JSON.stringify(cart));
  }

  function loadCart() {
    try {
      const store = storage();
      return store ? JSON.parse(store.getItem(STORAGE_KEY) || "null") : null;
    } catch (err) {
      return null;
    }
  }

  function buildIdentity(path, fields) {
    const identity = {
      path: path === "signin" ? "signin" : "create",
      accountMode: path === "signin" ? "returning" : "new"
    };
    Object.keys(fields || {}).forEach((key) => {
      if (SECRET_FIELDS[key]) {
        identity[key + "Present"] = !!String(fields[key] || "").trim();
        return;
      }
      identity[key] = fields[key];
    });
    return identity;
  }

  function saveIdentity(identity) {
    const store = storage();
    if (store) store.setItem(IDENTITY_KEY, JSON.stringify(identity));
  }

  function loadIdentity() {
    try {
      const store = storage();
      return store ? JSON.parse(store.getItem(IDENTITY_KEY) || "null") : null;
    } catch (err) {
      return null;
    }
  }

  function clearIdentity() {
    const store = storage();
    if (store) store.removeItem(IDENTITY_KEY);
  }

  function checkoutPath(programId) {
    return "/checkout/?program=" + encodeURIComponent(programId || "brokenyolk");
  }

  function landingPath(programId) {
    return "/" + (programId || "brokenyolk") + "/?setup=1";
  }

  function canPostToProCheckout(cart) {
    return !!(cart && cart.placeholders === false && cart.items && cart.items.length);
  }

  function beginCheckout(program, selections) {
    const cart = buildCart(program, selections);
    saveCart(cart);
    clearIdentity();
    return checkoutPath(program.programId);
  }

  async function startFromForm(form) {
    const data = Object.fromEntries(new FormData(form).entries());
    if (needsLead(data.hardwarePreference)) return false;
    const programId = data.programId || "brokenyolk";
    const res = await fetch("/programs/" + programId + ".json", { cache: "no-store" });
    if (!res.ok) throw new Error("Could not load program catalog");
    const program = await res.json();
    window.location.href = beginCheckout(program, data);
    return true;
  }

  const api = {
    STORAGE_KEY,
    IDENTITY_KEY,
    mapHardware,
    needsLead,
    setupNextStep,
    buildCart,
    saveCart,
    loadCart,
    buildIdentity,
    saveIdentity,
    loadIdentity,
    clearIdentity,
    checkoutPath,
    landingPath,
    canPostToProCheckout,
    beginCheckout,
    startFromForm
  };

  if (typeof module !== "undefined" && module.exports) {
    module.exports = api;
  }
  root.ProgramCheckout = api;
})(typeof window !== "undefined" ? window : globalThis);
