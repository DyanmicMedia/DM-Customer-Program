/**
 * Generic Dynamic Media checkout stand-in. Cart must already exist.
 * Field names follow ProCheckout; nothing posts to production while placeholders are true.
 */
(function () {
  const LABELS = {
    cart: "View Cart",
    account: "Account",
    location: "Licensing",
    shipping: "Shipping",
    billing: "Billing & Payment",
    review: "Review Order"
  };

  const state = {
    step: "account",
    path: null,
    program: null,
    cart: null,
    form: {}
  };

  function $(id) {
    return document.getElementById(id);
  }

  function money(n) {
    return "$" + Number(n).toFixed(2);
  }

  function collect(rootId) {
    const root = $(rootId);
    if (!root) return;
    root.querySelectorAll("input, select, textarea").forEach((el) => {
      if (!el.name) return;
      if (el.type === "checkbox") state.form[el.name] = el.checked;
      else if (el.type === "radio") {
        if (el.checked) state.form[el.name] = el.value;
      } else if (el.type === "password" || el.name === "ccNumber" || el.name === "ccCVV") {
        state.form[el.name + "Present"] = !!String(el.value || "").trim();
        el.value = "";
      } else {
        state.form[el.name] = el.value;
      }
    });
  }

  function afterLocation() {
    return state.cart && state.cart.hasShipping ? "shipping" : "billing";
  }

  function backFrom(step) {
    if (step === "cart") return "account";
    if (step === "location") return "cart";
    if (step === "shipping") return "location";
    if (step === "billing") return state.cart && state.cart.hasShipping ? "shipping" : "location";
    if (step === "review") return "billing";
    return "account";
  }

  function progressOrder() {
    const order = ["account", "cart", "location", "billing", "review"];
    if (state.cart && state.cart.hasShipping) order.splice(3, 0, "shipping");
    return order;
  }

  function renderProgress() {
    const order = progressOrder();
    const idx = Math.max(0, order.indexOf(state.step));
    const pct = Math.round(((idx + 1) / order.length) * 100);
    const steps = order.map((id, i) => {
      const cls = i < idx ? "is-done" : i === idx ? "is-current" : "is-todo";
      const mark = i < idx ? "✓" : String(i + 1);
      const current = i === idx ? ' aria-current="step"' : "";
      return `<li class="${cls}"${current}><span class="dm-step-mark" aria-hidden="true">${mark}</span><span class="dm-step-label">${LABELS[id]}</span></li>`;
    }).join("");
    $("progress").innerHTML =
      `<div class="dm-stepper-mobile">` +
        `<div class="dm-stepper-mobile-row"><span>Step ${idx + 1} of ${order.length}</span><strong>${LABELS[state.step]}</strong></div>` +
        `<div class="dm-stepper-bar" role="progressbar" aria-valuemin="1" aria-valuemax="${order.length}" aria-valuenow="${idx + 1}"><span style="width:${pct}%"></span></div>` +
      `</div>` +
      `<ol class="dm-stepper">${steps}</ol>`;
  }

  function itemRows(items) {
    return items.map((item) => {
      const rec = item.recurring ? " / mo" : "";
      return `<div class="dm-line-item"><span>${item.name}</span><span class="font-medium tabular-nums whitespace-nowrap">${money(item.price)}${rec}</span></div>`;
    }).join("");
  }

  function renderSummary() {
    const html = itemRows(state.cart.items) +
      `<div class="dm-line-total"><span>Subtotal</span><span class="tabular-nums">${money(state.cart.subtotal)}</span></div>`;
    $("orderSummary").innerHTML = html;
    $("orderSummaryMobile").innerHTML = html;
    $("summaryMobileTotal").textContent = money(state.cart.subtotal);
    $("cartBody").innerHTML = html;
  }

  function renderProductSites() {
    $("productSites").innerHTML = state.cart.items.map((item, i) => {
      return `<div>
        <label class="dm-label">${item.name}</label>
        <select name="product_${i}" class="dm-input">
          <option value="new">New address (form below)</option>
          <option value="" disabled>Saved locations appear after you log in</option>
        </select>
      </div>`;
    }).join("");
  }

  function showStep() {
    ["cart", "account", "location", "shipping", "billing", "review"].forEach((id) => {
      const el = $(id + "Step");
      if (!el) return;
      const hide = id !== state.step;
      el.classList.toggle("hidden", hide);
      el.toggleAttribute("hidden", hide);
    });
    renderProgress();
    const summaryMobile = $("summaryMobile");
    if (summaryMobile) summaryMobile.hidden = state.step === "cart";
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function go(step) {
    state.step = step;
    showStep();
  }

  document.addEventListener("DOMContentLoaded", async () => {
    const programId = new URLSearchParams(location.search).get("program") || "brokenyolk";
    const cart = window.ProgramCheckout.loadCart();
    if (!cart || cart.programId !== programId) {
      window.location.replace(window.ProgramCheckout.landingPath(programId));
      return;
    }
    state.cart = cart;

    const res = await fetch("/programs/" + programId + ".json", { cache: "no-store" });
    state.program = await res.json();
    $("businessName").value = state.program.programName || "";
    $("contactInstead").href = "/" + programId + "/#contact";
    renderSummary();
    renderProductSites();

    $("cartNext").addEventListener("click", () => go("location"));

    function showAccountCard(which) {
      const signin = which === "signin";
      $("signinCard").classList.toggle("hidden", !signin);
      $("createCard").classList.toggle("hidden", signin);
      $("signinCard").toggleAttribute("hidden", !signin);
      $("createCard").toggleAttribute("hidden", signin);
    }

    $("showCreateAccount").addEventListener("click", () => showAccountCard("create"));
    $("showSignin").addEventListener("click", () => showAccountCard("signin"));

    $("forgotToggle").addEventListener("click", () => {
      $("formForgot").classList.toggle("hidden");
    });

    $("forgotSend").addEventListener("click", () => {
      const email = $("usernameForgot").value.trim();
      $("forgotStatus").textContent = email
        ? "If an account exists for that email, reset instructions will be sent."
        : "Enter the email on the account.";
    });

    $("signinNext").addEventListener("click", () => {
      if (!$("formExisting").reportValidity()) return;
      collect("formExisting");
      state.path = "signin";
      state.form.accountMode = "returning";
      window.ProgramCheckout.saveIdentity(window.ProgramCheckout.buildIdentity("signin", state.form));
      go("cart");
    });

    $("createNext").addEventListener("click", () => {
      if (!$("formNew").reportValidity()) return;
      collect("formNew");
      state.path = "create";
      state.form.accountMode = "new";
      window.ProgramCheckout.saveIdentity(window.ProgramCheckout.buildIdentity("create", state.form));
      go("cart");
    });

    $("locationNext").addEventListener("click", () => {
      if (!$("formLocationInfo").reportValidity()) return;
      collect("productSites");
      collect("formLocationInfo");
      $("shippingString").value = [
        state.form.address1,
        state.form.city,
        state.form.state,
        state.form.zip
      ].filter(Boolean).join(", ");
      go(afterLocation());
    });

    $("shippingNext").addEventListener("click", () => {
      collect("shippingStep");
      go("billing");
    });

    $("billingNext").addEventListener("click", () => {
      if (!$("formBilling").reportValidity()) return;
      collect("formBilling");
      $("reviewBody").innerHTML = `
        <p>${state.form.accountMode === "returning" ? "Signed in" : "New account"} · ${state.form.emailAddress || state.form.username || ""}</p>
        <p>${state.form.siteName || ""} — ${state.form.address1 || ""}, ${state.form.city || ""} ${state.form.state || ""} ${state.form.zip || ""}</p>
        <p>${state.cart.hasShipping ? "Ship to " + (state.form.shippingString || "licensing address") : "No shipping on this cart"}</p>
        <p>Payment ${state.form.ccNumberPresent ? "entered (not stored)" : "not entered"}${state.form.billAddress2 ? " · " + state.form.billAddress2 : ""}</p>
      `;
      go("review");
    });

    document.querySelectorAll("[data-back]").forEach((btn) => {
      btn.addEventListener("click", () => go(backFrom(state.step)));
    });

    $("placeOrder").addEventListener("click", () => {
      if (!$("formAcknowledgements").reportValidity()) return;
    });

    showStep();
  });
})();
